function Mostrar()
{
//tomo la hora
var laHora = document.getElementById('hora').value;



}//FIN DE LA FUNCIÓN