function Mostrar()
{
//tomo el mes
var mesDelAño = document.getElementById('mes').value;




}//FIN DE LA FUNCIÓN