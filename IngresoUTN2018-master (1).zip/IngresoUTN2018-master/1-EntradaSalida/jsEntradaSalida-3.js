/*Debemos lograr tomar un dato por 'ID'
y luego mostrarlo por 'Alert' al presionar el botón  'MOSTRAR'*/
function Mostrar()
{
	//declaro la variable 

    var nombre;

    // uno el documento Html por la caja de texto  
    nombre=document.getElementById("elNombre").value;

    //cierro con la variable para indicar el nombre

    alert (nombre); 

     
}


