/*Debemos lograr tomar un nombre con 'prompt' 
y luego mostrarlo por 'alert' al presionar el botón  'MOSTRAR'*/
function Mostrar()
{ 
    //declaro una variable siempre al principio  
    var dato; 
   
    //pido algun dato para ingresar 
    dato = prompt ("Ingrese un dato");
	
    // muestra el contenido de esa variable que es dato 
    alert(dato);
}